var searchData=
[
  ['undecoration_5fcomplete',['UNDECORATION_COMPLETE',['../group__SYM__BASIC__API.html#gga2b7e9b0b1d3e5d38135695bdb1b380fea97005f7701a8e2ce6a060b31f7fb3287',1,'LEVEL_PINCLIENT']]],
  ['undecoration_5fname_5fonly',['UNDECORATION_NAME_ONLY',['../group__SYM__BASIC__API.html#gga2b7e9b0b1d3e5d38135695bdb1b380fea22890064021b2aa1f9f2754d181b7073',1,'LEVEL_PINCLIENT']]]
];
