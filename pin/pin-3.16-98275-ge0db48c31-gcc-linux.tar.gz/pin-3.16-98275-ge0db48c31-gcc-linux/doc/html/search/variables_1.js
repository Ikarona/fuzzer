var searchData=
[
  ['invalid_5fos_5fthread_5fid',['INVALID_OS_THREAD_ID',['../group__PIN__THREAD__API.html#gad736d7bd6f0a29b0ca5c8ebb6153b9d0',1,'types_vmapi.H']]],
  ['invalid_5fpin_5fthread_5fuid',['INVALID_PIN_THREAD_UID',['../group__PIN__THREAD__API.html#gaae11dfbf7d439196f8d24d3e463c275b',1,'types_vmapi.H']]],
  ['invalid_5fthreadid',['INVALID_THREADID',['../group__PIN__THREAD__API.html#ga81c8bec30de2cbb5336b3d2d7d817466',1,'types_vmapi.H']]],
  ['invalid_5ftls_5fkey',['INVALID_TLS_KEY',['../group__PIN__THREAD__API.html#ga7a22817a78367ba432a8121df3d7b461',1,'LEVEL_BASE']]]
];
