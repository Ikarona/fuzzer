var searchData=
[
  ['level_5fbase',['LEVEL_BASE',['../namespaceLEVEL__BASE.html',1,'']]],
  ['level_5fcore',['LEVEL_CORE',['../namespaceLEVEL__CORE.html',1,'']]],
  ['level_5fpinclient',['LEVEL_PINCLIENT',['../namespaceLEVEL__PINCLIENT.html',1,'']]]
];
