var searchData=
[
  ['faulty_5faccess_5ftype',['FAULTY_ACCESS_TYPE',['../group__EXCEPTION__API.html#ga360af8d7af72a0f432e95f0a3abce37d',1,'LEVEL_BASE']]],
  ['fperror',['FPERROR',['../group__EXCEPTION__API.html#gaa6076934993f2f3c516daf77e669d2c5',1,'LEVEL_BASE']]],
  ['fpoint',['FPOINT',['../group__PIN__CONTROL.html#gab459bf0034704bf1aa7fa7e192b7dc08',1,'LEVEL_PINCLIENT']]]
];
