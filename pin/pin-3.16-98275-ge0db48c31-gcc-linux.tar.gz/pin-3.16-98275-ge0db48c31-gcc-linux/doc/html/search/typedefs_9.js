var searchData=
[
  ['reg_5fclass_5fbits',['REG_CLASS_BITS',['../group__REG__CPU__IA32.html#ga5b0b71675518f3b3e967334d71a967d4',1,'LEVEL_BASE']]],
  ['regset',['REGSET',['../group__REG__CPU__IA32.html#gae457153aab05650d6845e3553731ee63',1,'LEVEL_CORE']]],
  ['remove_5finstrumentation_5fcallback',['REMOVE_INSTRUMENTATION_CALLBACK',['../group__PIN__CONTROL.html#gab3fdb5c00cacaeb25c3aa3db43b84fef',1,'LEVEL_PINCLIENT']]],
  ['root_5fthread_5ffunc',['ROOT_THREAD_FUNC',['../group__PIN__THREAD__API.html#gaf7d4b7206749ac3075b941a513d876c5',1,'types_vmapi.H']]],
  ['rtn_5finstrument_5fcallback',['RTN_INSTRUMENT_CALLBACK',['../group__RTN__BASIC__API.html#ga2c163b4323b6afef555cfcc4776bce3d',1,'LEVEL_PINCLIENT']]]
];
