var searchData=
[
  ['os_5fapis_5fipc_5fsendto_5fflags',['OS_APIS_IPC_SENDTO_FLAGS',['../group__OS__APIS__IPC.html#gab1d4d01ba1dcfa1faaf28c50874c1eb6',1,'ipc.h']]],
  ['os_5fapis_5fipc_5fshutdown',['OS_APIS_IPC_SHUTDOWN',['../group__OS__APIS__IPC.html#ga26c0ad3e94afe7b80683866c7cda8896',1,'ipc.h']]],
  ['os_5fapis_5fipc_5fsocket_5fdomain',['OS_APIS_IPC_SOCKET_DOMAIN',['../group__OS__APIS__IPC.html#ga7d64e90581bdd8948ed13f30f6b6a522',1,'ipc.h']]],
  ['os_5fapis_5fipc_5fsocket_5fprotocol',['OS_APIS_IPC_SOCKET_PROTOCOL',['../group__OS__APIS__IPC.html#gaab521f2803eec423dc1cd570b88d90d2',1,'ipc.h']]],
  ['os_5fapis_5fipc_5fsocket_5ftype',['OS_APIS_IPC_SOCKET_TYPE',['../group__OS__APIS__IPC.html#ga0de2b9d6f60ccba50e4c7db19697a45a',1,'ipc.h']]],
  ['os_5ffile_5fattributes',['OS_FILE_ATTRIBUTES',['../group__OS__APIS__FILE.html#ga72758a31adaf5c4afde4341e70a848e7',1,'file.h']]],
  ['os_5ffile_5fopen_5ftype',['OS_FILE_OPEN_TYPE',['../group__OS__APIS__FILE.html#gaf79cb66b43257af42f5e75915c9d3b46',1,'file.h']]],
  ['os_5ffile_5fpermission',['OS_FILE_PERMISSION',['../group__OS__APIS__FILE.html#gaf479f66e1623df5edfa3e38f040f5088',1,'file.h']]],
  ['os_5ffile_5fseek_5ftype',['OS_FILE_SEEK_TYPE',['../group__OS__APIS__FILE.html#gacd4e4a1518bf251af4bfd2a8fe697026',1,'file.h']]],
  ['os_5fhost_5fcpu_5farch_5ftype',['OS_HOST_CPU_ARCH_TYPE',['../group__OS__APIS__HOST.html#ga0df31212789b90ca6b23a8c008b5c120',1,'host.h']]],
  ['os_5fmemory_5fflags',['OS_MEMORY_FLAGS',['../group__OS__APIS__MEMORY.html#gac040a9da8f2a5ffbefe23e96a14b97f3',1,'memory.h']]],
  ['os_5fpage_5fprotection_5ftype',['OS_PAGE_PROTECTION_TYPE',['../group__OS__APIS__MEMORY.html#ga8b1f83ef2e6ff5fd685c9beb6249fbec',1,'memory.h']]],
  ['os_5fpipe_5fcreate_5fflags',['OS_PIPE_CREATE_FLAGS',['../group__OS__APIS__FILE.html#ga3b5104eac807de465009822c2b5d83cc',1,'ipc-pipe.h']]],
  ['os_5freturn_5fcode_5fgeneric',['OS_RETURN_CODE_GENERIC',['../group__OS__APIS__DEF.html#ga00cc35ef61ed25e2c8815c3d8d49f7ca',1,'os_return_codes.h']]]
];
